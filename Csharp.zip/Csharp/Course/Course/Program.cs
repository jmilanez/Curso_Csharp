﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Course_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Triangulo x,y;

            x = new Triangulo();
            y = new Triangulo();

            Console.WriteLine("Digite as informações do trinagulo X: ");
            x.A = double.Parse(Console.ReadLine());
            x.B = double.Parse(Console.ReadLine());
            x.C = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite as informações do trinagulo Y: ");
            y.A = double.Parse(Console.ReadLine());
            y.B = double.Parse(Console.ReadLine());
            y.C = double.Parse(Console.ReadLine());

            double areaX = x.Area();

            double areaY = y.Area();

            Console.WriteLine("A area de X é: " + areaX);
            Console.WriteLine("A area de Y é: " + areaY.ToString("F4"));

            if (areaX > areaY){
                Console.WriteLine("A area X é a maior");
            }else
            {
                Console.WriteLine("A area Y é a maior");
            }

            Console.WriteLine("Clique para finalizar!");
            Console.ReadLine();*/

            //Fazer um programa para ler os dados de duas pessoas, depois mostrar o nome da pessoa mais velha

            /*Pessoa p1, p2;
            p1 = new Pessoa();
            p2 = new Pessoa();
            int cont = 0;

            Console.WriteLine("Digite seu nome: ");
            p1.nome = Console.ReadLine();
            Console.WriteLine("Digite sua idade: ");
            p1.idade = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite seu nome: ");
            p2.nome = Console.ReadLine();
            Console.WriteLine("Digite sua idade: ");
            p2.idade = int.Parse(Console.ReadLine());

            if (p1.idade > p2.idade){
                Console.WriteLine($"{p1.nome} é a pessoa mais velha!");
                Console.ReadLine();
            }else{
                Console.WriteLine($"{p2.nome} é a pessoa mais velha!");
                Console.ReadLine();
            }*/

            /*Pessoa p1, p2;
            p1 = new Pessoa();
            p2 = new Pessoa();
            int cont = 0;

            Console.WriteLine("Digite seu nome: ");
            p1.nome = Console.ReadLine();
            Console.WriteLine("Digite seu salario: ");
            p1.sal = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite seu nome: ");
            p2.nome = Console.ReadLine();
            Console.WriteLine("Digite seu salario: ");
            p2.sal = int.Parse(Console.ReadLine());

            double media_sal = (p1.sal + p2.sal)  / 2;

            Console.WriteLine($"A media salarial dos funcionarios é de {media_sal}");
            Console.ReadLine();*/

            /*Produto p = new Produto();

            Console.WriteLine("Entre com os dados do prouto");
            Console.Write("Nome: ");
            p.Nome = Console.ReadLine();

            Console.Write("Preço: ");
            p.Preco = double.Parse(Console.ReadLine());

            Console.Write("Quantidade do estoque: ");
            p.Qntd = int.Parse(Console.ReadLine());

            Console.WriteLine("Dados do produto: " + p);
            Console.ReadLine();

            Console.WriteLine();
            Console.WriteLine("Digite os numeros de produtos a serem adicionados: ");
            int qtde = int.Parse(Console.ReadLine());
            p.AdicionarProdutos(qtde);
            Console.WriteLine("Dados atualizados: " + p);

            Console.WriteLine();
            Console.WriteLine("Digite os numeros de produtos a serem removidos: ");
            qtde = int.Parse(Console.ReadLine());
            p.RemoverProdutos(qtde);
            Console.WriteLine("Dados atualizados: " + p);

            Console.ReadLine();*/


            /*Retangulo ret = new Retangulo();
            Console.WriteLine("Entre a largura e altura do retângulo: ");
            ret.Largura = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
            ret.Altura = double.Parse(Console.ReadLine(), CultureInfo.InvariantCulture);
            Console.WriteLine("AREA = " + ret.Area().ToString("F2", CultureInfo.InvariantCulture));
            Console.WriteLine("PERIMETRO = " + ret.Perimetro().ToString("F2", CultureInfo.InvariantCulture));
            Console.WriteLine("DIAGONAL = " + ret.Diagonal().ToString("F2", CultureInfo.InvariantCulture));*/

            Salario sal = new Salario();
            Console.WriteLine("Programa Salario\n");
            Console.ReadLine();
            Console.Write("Digite seu nome: ");
            sal.Nome = Console.ReadLine();
            Console.Write("Salário Bruto: ");
            sal.SalarioBruto = double.Parse(Console.ReadLine());
            Console.Write("Imposto: ");
            sal.Imposto = double.Parse(Console.ReadLine());
            Console.WriteLine($"Funcionário: {sal}");
            Console.Write("Digite a porcentagem para aumentar o salario: ");
            Console.Write($"Dados atualizados: {sal}");
            Console.ReadLine();

        }
    }
}
