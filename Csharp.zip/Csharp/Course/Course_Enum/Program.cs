﻿using System;
using System.Globalization;
using Course_Enum.Entities.Enums;

namespace Course_Enum
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Order order = new Order
            {
                Id = 1080,
                Moment = DateTime.Now,
                Status = OrderStatus.PedingPayment
            };

            Console.WriteLine(order);

            string txt = OrderStatus.PedingPayment.ToString();

            OrderStatus os = Enum.Parse<OrderStatus>("Delivered");

            Console.WriteLine(os);
            Console.WriteLine(txt);*/
            InfoEmployee info = new InfoEmployee();
            LevelEmployee lvl = new LevelEmployee();
            int cont = 0;
            int opcao = 0;

            Console.WriteLine("Enter departament´s name: ");
            info.departament = Console.ReadLine();
            Console.WriteLine("Enter worker data");
            Console.WriteLine("Name: ");
            info.name = Console.ReadLine();
            Console.WriteLine("Level(Junior/MidLevel/Senior): ");
            lvl = Enum.Parse<LevelEmployee>(Console.ReadLine());
            Console.WriteLine("Base Salary: ");
            info.salary = int.Parse(Console.ReadLine());
            do
            {
                cont++;
                Console.WriteLine("Enter #" + cont + " contract data");
                Console.WriteLine("Date(DD/MM/YYYY): ");
                Console.ReadLine();
                Console.WriteLine("Value per hour: ");
                Console.ReadLine();
                Console.WriteLine("Duration(hours): ");
                Console.ReadLine();
                Console.WriteLine("Deseja digitar um novo contrato?[1-s/2-n]: ");
                opcao = int.Parse(Console.ReadLine());
            } while (opcao == 1);

            Console.WriteLine();
            Console.Write("Enter month and year to calculate income (MM/YYYY): ");
            string monthAndYear = Console.ReadLine();
            int month = int.Parse(monthAndYear.Substring(0, 2));
            int year = int.Parse(monthAndYear.Substring(3));
            Console.WriteLine("Name : " + info.name);
            Console.WriteLine("Department: " + info.departament);
            Console.WriteLine("Income for " + monthAndYear + ": " + info.Income(year, month).ToString("F2", CultureInfo.InvariantCulture));
            Console.ReadLine();
        }
    }
}
