﻿using Course.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Course_Enum
{
    public class InfoEmployee
    {
        public string departament;
        public string name;
        public double salary;
        public DateTime date_contract;
        public double valueHour;

        public double Income(int year, int month)
        {
            double sum = salary;
            foreach (valueHour contract in Contracts)
            {
                if (contract.Date.Year == year && contract.Date.Month == month)
                {
                    sum += contract.TotalValue();
                }
            }
            return sum;
        }
    }
}
