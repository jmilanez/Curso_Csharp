﻿namespace Course_Enum.Entities.Enums
{
    enum LevelEmployee : int
    {
        Junior = 0,
        MidLevel = 1,
        Senior = 2
    }
}
