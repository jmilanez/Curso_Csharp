﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Course_Heranca_Polimorfismo.Entities
{
    class Products
    {
        public string Name { get; set; }
        public double Price { get; set; }

        public Products()
        {

        }

        public Products(string name, double price)
        {
            name = Name;
            price = Price;
        }

        public virtual string priceTag()
        {
            return Name + "$" + Price.ToString(CultureInfo.InvariantCulture);
        }
    }
}
