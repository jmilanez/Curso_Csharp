﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Course_const
{
    class Banco
    {
        public string titular { get; set; }
        public string numeroConta { get; set; }
        public double saldo { get; set; }
        public double deposito { get; set; }
        public double saque { get; set; }

        public Banco(string titular, string numeroConta, double saldo)
        {
            this.titular = titular;
            this.numeroConta = numeroConta;
            this.saldo = saldo;
        }

        public Banco()
        {
            
        }

        public double Deposito()
        {
            return saldo = saldo + deposito;
        }

        public double Saque()
        {
            return saldo = saldo - saque;
        }
    }
}
