﻿using System;
using System.Globalization;

namespace Course_Array
{
    class Triangulo
    {
        public double A;
        public double B;
        public double C;

        public double Area(){
            double p = (A + B + C) / 2;
            return Math.Sqrt(p * (p - A) * (p - B) * (p - C));
        }
    }

    class Pessoa
    {
        public string Nome;
        public int Idade;
        public double Sal;

    }

    class Produto
    {
        public string Nome;
        public double Preco;
        public int Qntd;

        public double ValorTotalEmEstoque(){
            return Preco * Qntd;
        }

        public void AdicionarProdutos(int quantidade)
        {
            Qntd += quantidade;
        }

        public void RemoverProdutos(int quantidade)
        {
            Qntd -= quantidade;
        }

        public override string ToString()
        {
            return Nome + ", $" + Preco.ToString("F2", CultureInfo.InvariantCulture)+", "+ Qntd +" unidades, total: $"+ValorTotalEmEstoque().ToString("F2", CultureInfo.InvariantCulture);
        }
    }
    class Retangulo
    {
        public double Largura;
        public double Altura;
        public double Area()
        {
            return Largura * Altura;
        }
        public double Perimetro()
        {
            return 2 * (Largura + Altura);
        }
        public double Diagonal()
        {
            return Math.Sqrt(Largura * Largura + Altura * Altura);
        }
    }

    class Salario
    {
        public string Nome;
        public double SalarioBruto;
        public double Imposto;
        public double SalarioLiquido;

        public double DescontoSalario()
        {
            return SalarioLiquido = (SalarioBruto - Imposto);
        }

        public void AumentarSalario(double porcentagem)
        {
            SalarioBruto = SalarioBruto + (SalarioBruto * porcentagem / 100.0);
        }
    }
}
