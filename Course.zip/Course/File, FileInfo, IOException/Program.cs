﻿using System;
using System.IO;

namespace File__FileInfo__IOException
{
    class Program
    {
        static void Main(string[] args)
        {
            string sourcePath = @"C:\Temp\file1.txt";
            string targetPath = @"C:\Temp\file2.txt";

            string[] lines = File.ReadAllLines(sourcePath);
            foreach (string line in lines)
            {
                Console.WriteLine(line);
            }

            try
            {
                FileInfo fileInfo = new FileInfo(sourcePath);
                fileInfo.CopyTo(targetPath);
            }
            catch(IOException e)
            {
                Console.Write("An error occurred "+e.Message);
            }
        }
    }
}
